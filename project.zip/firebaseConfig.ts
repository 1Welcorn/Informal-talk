// IMPORTANT: Replace this with your own Firebase project configuration.
// You can get this from the Firebase console for your web app.
// Go to Project settings > General > Your apps > Web app > SDK setup and configuration
export const firebaseConfig = {
  apiKey: "AIzaSyBQak8Ow4Oso8Ux_Tf3XdSknYAsot_J0T0",
  authDomain: "informal-talk.firebaseapp.com",
  projectId: "informal-talk",
  storageBucket: "informal-talk.appspot.com",
  messagingSenderId: "1076375691700",
  appId: "1:1076375691700:web:bf7a20e6f9e7ced20fd2e1"
};
